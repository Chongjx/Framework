#ifndef MINI_MAP_H
#define MINI_MAP_H

#include "Mesh.h" 
#include <vector>

struct Avatar
{
	Avatar();
	~Avatar();
	Mesh* avatarMesh;
	float xCoord;
	float yCoord;
	float angle;

	// Set the Avatar mesh to this class 
	bool setAvatar(Mesh* anAvatar);
	bool setAngle(const float _angle);
	bool setPosition(const float x, const float y);
	
	// Get the Avatar mesh to this class 
	Mesh* getAvatar(void) const;
	float getAngle(void) const;	
	float getPosition_x(void); 	
	float getPosition_y(void); 
};

class MiniMap 
{
public: 
	MiniMap(void);  	
	virtual ~MiniMap(void); 

	Mesh* m_MiniMap_Background;  	
	Mesh* m_MiniMap_Border;
	std::vector<Avatar> avatarList;

	// Set the background mesh to this class  	
	bool SetBackground(Mesh* aBackground);  	
	// Get the background mesh to this class  	
	Mesh* GetBackground(void); 
	// Set the Border mesh to this class  	
	bool SetBorder(Mesh* aBorder);  	
	// Get the Border mesh to this class 
	Mesh* GetBorder(void);  

	// Set size of minimap (for calculation of avatar in minimap)
	bool SetSize(const float x, const float y);

	// Get size of minimap (for calculation of avatar in minimap)  
	int GetSize_x(void); 
	// Get size of minimap (for calculation of avatar in minimap)  	
	int GetSize_y(void); 
private: 
	// Minimap size  	
	float size_x, size_y; 
};  

#endif