#include "Character.h"

Character::Character(void)
{
}

Character::~Character(void)
{
}
