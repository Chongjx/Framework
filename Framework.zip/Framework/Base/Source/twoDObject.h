#ifndef TWO_D_OBJECT_H
#define TWO_D_OBJECT_H

#include "GameObject.h"

class twoDObject
{
public:
	twoDObject(void);
	~twoDObject(void);
};

#endif