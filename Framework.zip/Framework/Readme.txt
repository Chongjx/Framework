Game: Alien Planet
The year is 2046 when human discovered hostile lifeforms on NOVA83. You are sent on a scouting mission but your plane crashed. 
Help is coming but can you survive?

Aim: Survive as long as possible until help arrive.

Controls: 
W - move forward
A - move left
S - move backward
D - move right
Spacebar - jump

mouse rotation - rotate

left click - shoot
right click - switch weapon

R - reload

SideNote:
There isnt gameover screen, so the health can go below 0



